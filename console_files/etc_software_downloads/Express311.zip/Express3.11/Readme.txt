This zip file includes two *.bin files.  

e2.bin   --  updated console software
run.bin  --  nodes disk software

To use either software, put its .bin file by itself on a freshly formatted floppy disk.
Insert the disk into the console and turn the console off and back on.
The software should load.